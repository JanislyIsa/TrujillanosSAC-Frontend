import { bootstrapApplication } from '@angular/platform-browser';
import { provideHttpClient, withXsrfConfiguration, withInterceptors } from '@angular/common/http';
import { provideRouter, withComponentInputBinding, withHashLocation } from '@angular/router';
import { App } from './app/app';
import { routes } from './app/app.routes';
import { sesionInterceptor } from './app/core/auth';
import { bearerInterceptor } from './app/features/ventas/services/bearer-interceptor';
bootstrapApplication(App, {
  providers: [
    provideHttpClient(withInterceptors([sesionInterceptor, bearerInterceptor]),withXsrfConfiguration({ cookieName: 'XSRF-TOKEN', headerName: 'X-XSRF-TOKEN' })),
    provideRouter(routes, withHashLocation(), withComponentInputBinding()),
  ],
}).catch(error => console.error('No se pudo iniciar inventario', error));
