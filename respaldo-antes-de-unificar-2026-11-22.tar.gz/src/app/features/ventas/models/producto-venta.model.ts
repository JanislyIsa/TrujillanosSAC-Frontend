export interface ProductoVenta {
  idProducto: number;
  nombre: string;
  descripcion: string | null;
  precio: number;
  stock: number;
  categoria: string | null;
  presentacion: string | null;
  imagenUrl: string | null;
}

export type TipoPresentacion = 'caja' | 'paquete';

/**
 * En la tabla PRODUCTO el mismo producto (ej. «Tetin POP») aparece en una fila por presentación:
 * una fila PAQUETE y otra CAJA, cada una con su propio precio y stock.
 */
export interface GrupoProducto {
  nombre: string;
  /** Variantes del producto: primero Paquete y luego Caja. */
  variantes: ProductoVenta[];
}

/** Caja o Paquete (la Bolsa se vende como paquete). */
export function tipoPresentacion(p: ProductoVenta): TipoPresentacion {
  return (p.presentacion ?? '').toLowerCase().includes('caja') ? 'caja' : 'paquete';
}

/** Agrupa las filas del catálogo que tienen el mismo nombre (una por presentación). */
export function agruparProductos(lista: ProductoVenta[]): GrupoProducto[] {
  const grupos = new Map<string, GrupoProducto>();
  for (const p of lista) {
    const clave = p.nombre.trim().toLowerCase();
    const grupo = grupos.get(clave) ?? { nombre: p.nombre.trim(), variantes: [] };
    grupo.variantes.push(p);
    grupos.set(clave, grupo);
  }
  const orden = (p: ProductoVenta) => (tipoPresentacion(p) === 'paquete' ? 0 : 1);
  return [...grupos.values()].map((g) => ({ ...g, variantes: [...g.variantes].sort((a, b) => orden(a) - orden(b)) }));
}

/** Variante de una presentación dentro del grupo, si existe. */
export function variante(grupo: GrupoProducto, tipo: TipoPresentacion): ProductoVenta | undefined {
  return grupo.variantes.find((v) => tipoPresentacion(v) === tipo);
}

/** Primer valor no vacío entre las variantes (la descripción y la foto pueden estar solo en una fila). */
export function primerDato(grupo: GrupoProducto, campo: 'descripcion' | 'imagenUrl'): string | null {
  return grupo.variantes.map((v) => v[campo]).find((x) => !!x && x.trim() !== '') ?? null;
}
