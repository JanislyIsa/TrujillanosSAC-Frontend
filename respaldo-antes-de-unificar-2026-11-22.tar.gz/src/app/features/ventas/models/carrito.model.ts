import { ProductoVenta } from './producto-venta.model';

export interface ItemCarrito {
  producto: ProductoVenta;
  cantidad: number;
}
