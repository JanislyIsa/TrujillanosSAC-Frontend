export interface EstadoPedido {
  id: number;
  codigo: string;
  nombre: string;
}
export interface DetallePedido {
  idDetalle: number;
  productoId: number;
  nombreProducto: string;
  cantidad: number;
  precioUnitario: number;
  subtotal: number;
}
export interface Pedido {
  idPedido: number;
  fechaRegistro: string;
  clienteId: number;
  estado: EstadoPedido;
  total: number;
  detalles: DetallePedido[];
}
export interface DetallePedidoRequest {
  productoId: number;
  cantidad: number;
}
export interface PedidoRequest {
  detalles: DetallePedidoRequest[];
}

/** Texto del estado tal como lo ve el cliente. */
export function etiquetaEstado(codigo: string): string {
  const etiquetas: Record<string, string> = {
    PENDIENTE: 'Pendiente de pago',
    PROCESANDO_PAGO: 'Procesando pago',
    PAGADO: 'Pagado',
    LISTO_PARA_RECOJO: 'Listo para recojo',
    ENTREGADO: 'Recogido',
    CANCELADO: 'Cancelado',
  };
  return etiquetas[codigo] ?? codigo;
}

/** Resumen de los productos de un pedido: "A (x2), B (x1) y C (x3)". */
export function resumenProductos(pedido: Pedido): string {
  const partes = pedido.detalles.map((d) => `${d.nombreProducto} (x${d.cantidad})`);
  if (partes.length <= 1) return partes.join('');
  return `${partes.slice(0, -1).join(', ')} y ${partes[partes.length - 1]}`;
}

/** Clase CSS del badge según el estado del pedido. */
export function claseEstado(codigo: string): 'ok' | 'malo' | 'info' | 'pendiente' {
  switch (codigo) {
    case 'PAGADO':
    case 'LISTO_PARA_RECOJO':
    case 'ENTREGADO':
      return 'ok';
    case 'CANCELADO':
      return 'malo';
    case 'PROCESANDO_PAGO':
      return 'info';
    default:
      return 'pendiente';
  }
}
