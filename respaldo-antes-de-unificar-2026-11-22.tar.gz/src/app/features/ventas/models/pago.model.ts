export interface Pago {
  idPago: number;
  pedidoId: number;
  metodoPago: string;
  estado: string;
  fechaPago: string;
  monto: number;
  moneda: string;
  referenciaExterna: string | null;
  mensaje: string | null;
}
export interface PagoCulqiRequest {
  pedidoId: number;
  token: string;
  email: string;
}
