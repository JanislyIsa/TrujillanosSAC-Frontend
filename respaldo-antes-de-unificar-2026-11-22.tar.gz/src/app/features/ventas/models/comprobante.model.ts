export type TipoComprobante = 'BOLETA' | 'FACTURA';

export interface Comprobante {
  idComprobante: number;
  pedidoId: number;
  tipo: string;
  estado: string;
  serie: string | null;
  numero: number | null;
  fechaEmision: string | null;
  total: number;
  estadoSunat: string | null;
}
export interface ComprobanteRequest {
  pedidoId: number;
  tipo: TipoComprobante;
}
