export interface LoginRequest {
  username: string;
  password: string;
}
export interface LoginResponse {
  token: string;
  tipo: string;
  expiraEnSegundos: number;
  username: string;
  nombreCompleto: string;
  roles: string[];
  permisos: string[];
}
