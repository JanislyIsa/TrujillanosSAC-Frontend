import { computed, Service, signal } from '@angular/core';
import { ItemCarrito } from '../models/carrito.model';
import { ProductoVenta } from '../models/producto-venta.model';

const CLAVE = 'trujillano.tienda.carrito';
const MAXIMO_POR_ITEM = 1000; // el backend rechaza más de 1000 unidades por producto

@Service()
export class CarritoService {
  private readonly lista = signal<ItemCarrito[]>(this.leer());

  readonly items = this.lista.asReadonly();
  readonly cantidadTotal = computed(() => this.lista().reduce((suma, i) => suma + i.cantidad, 0));
  readonly total = computed(
    () => Math.round(this.lista().reduce((s, i) => s + i.producto.precio * i.cantidad, 0) * 100) / 100,
  );

  cantidadDe(idProducto: number): number {
    return this.lista().find((i) => i.producto.idProducto === idProducto)?.cantidad ?? 0;
  }

  agregar(producto: ProductoVenta): void {
    this.fijar(producto, this.cantidadDe(producto.idProducto) + 1);
  }

  fijar(producto: ProductoVenta, cantidad: number): void {
    const tope = Math.max(0, Math.min(producto.stock, MAXIMO_POR_ITEM));
    const nueva = Math.max(0, Math.min(Math.floor(cantidad) || 0, tope));
    const resto = this.lista().filter((i) => i.producto.idProducto !== producto.idProducto);
    const items =
      nueva === 0
        ? resto
        : [...resto, { producto, cantidad: nueva }].sort((a, b) =>
            a.producto.nombre.localeCompare(b.producto.nombre),
          );
    this.guardar(items);
  }

  quitar(idProducto: number): void {
    this.guardar(this.lista().filter((i) => i.producto.idProducto !== idProducto));
  }

  vaciar(): void {
    this.guardar([]);
  }

  private guardar(items: ItemCarrito[]): void {
    this.lista.set(items);
    try {
      localStorage.setItem(CLAVE, JSON.stringify(items));
    } catch {
      /* sin storage */
    }
  }

  private leer(): ItemCarrito[] {
    try {
      return JSON.parse(localStorage.getItem(CLAVE) ?? '[]') as ItemCarrito[];
    } catch {
      return [];
    }
  }
}
