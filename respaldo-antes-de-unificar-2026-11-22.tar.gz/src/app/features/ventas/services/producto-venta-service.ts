import { inject, Service } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { ProductoVenta } from '../models/producto-venta.model';

@Service()
export class ProductoVentaService {
  private readonly http = inject(HttpClient);
  private readonly url = `${environment.apiUrl}/ventas/productos`;

  listar(): Observable<ProductoVenta[]> {
    return this.http.get<ProductoVenta[]>(this.url);
  }
  obtener(id: number): Observable<ProductoVenta> {
    return this.http.get<ProductoVenta>(`${this.url}/${id}`);
  }
}
