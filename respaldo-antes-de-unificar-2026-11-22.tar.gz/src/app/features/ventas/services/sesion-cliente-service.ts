import { HttpClient } from '@angular/common/http';
import { computed, inject, Service, signal } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, tap } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { LoginRequest, LoginResponse } from '../models/auth.model';

const CLAVE = 'trujillano.tienda.sesion';

/** Sesión JWT del cliente. Se guarda en sessionStorage: se borra al cerrar la pestaña. */
@Service()
export class SesionClienteService {
  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);
  private readonly datos = signal<LoginResponse | null>(this.leer());
  private destino: string | null = null;

  readonly autenticado = computed(() => this.datos() !== null);
  readonly nombre = computed(() => this.datos()?.nombreCompleto || this.datos()?.username || '');
  readonly token = computed(() => this.datos()?.token ?? null);
  /** Controla la ventana de inicio de sesión (modal) sobre el catálogo. */
  readonly loginAbierto = signal(false);

  /** Abre el login; al iniciar sesión se continúa hacia `destino` (la página que el cliente quería ver). */
  abrirLogin(destino: string | null = null): void {
    this.destino = destino;
    this.loginAbierto.set(true);
  }

  cerrarLogin(): void {
    this.destino = null;
    this.loginAbierto.set(false);
  }

  iniciarSesion(dto: LoginRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${environment.apiUrl}/auth/login`, dto).pipe(
      tap((respuesta) => {
        if (!respuesta.roles.includes('CLIENTE')) {
          throw new Error('Esta tienda es solo para clientes. Usa una cuenta con rol CLIENTE.');
        }
        this.guardar(respuesta);
        const destino = this.destino;
        this.cerrarLogin();
        if (destino) void this.router.navigateByUrl(destino);
      }),
    );
  }

  cerrarSesion(): void {
    try {
      sessionStorage.removeItem(CLAVE);
    } catch {
      /* sin storage */
    }
    this.datos.set(null);
    void this.router.navigate(['/tienda']);
  }

  private guardar(respuesta: LoginResponse): void {
    const vence = Date.now() + respuesta.expiraEnSegundos * 1000;
    try {
      sessionStorage.setItem(CLAVE, JSON.stringify({ ...respuesta, vence }));
    } catch {
      /* sin storage */
    }
    this.datos.set(respuesta);
  }

  private leer(): LoginResponse | null {
    try {
      const crudo = sessionStorage.getItem(CLAVE);
      if (!crudo) return null;
      const guardado = JSON.parse(crudo) as LoginResponse & { vence?: number };
      if (guardado.vence && Date.now() > guardado.vence) {
        sessionStorage.removeItem(CLAVE);
        return null;
      }
      return guardado;
    } catch {
      return null;
    }
  }
}
