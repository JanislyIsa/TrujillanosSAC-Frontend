import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { tap } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { SesionClienteService } from './sesion-cliente-service';

const VENTAS = `${environment.apiUrl}/ventas`;
const AUTH = `${environment.apiUrl}/auth`;
const LOGIN = `${AUTH}/login`;

/** Agrega el JWT solo a las URLs de ventas y auth; si el backend responde 401 cierra la sesión. */
export const bearerInterceptor: HttpInterceptorFn = (req, next) => {
  if (!req.url.startsWith(VENTAS) && !req.url.startsWith(AUTH)) return next(req);
  const sesion = inject(SesionClienteService);
  const token = sesion.token();
  const esLogin = req.url.startsWith(LOGIN);
  const peticion = token && !esLogin ? req.clone({ setHeaders: { Authorization: `Bearer ${token}` } }) : req;
  return next(peticion).pipe(
    tap({
      error: (err: unknown) => {
        if (err instanceof HttpErrorResponse && err.status === 401 && !esLogin) sesion.cerrarSesion();
      },
    }),
  );
};
