import { inject, Service } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { Pago, PagoCulqiRequest } from '../models/pago.model';

@Service()
export class PagoService {
  private readonly http = inject(HttpClient);
  private readonly url = `${environment.apiUrl}/ventas/pagos`;

  listarPorPedido(pedidoId: number): Observable<Pago[]> {
    return this.http.get<Pago[]>(this.url, { params: { pedidoId } });
  }
  pagarConCulqi(dto: PagoCulqiRequest): Observable<Pago> {
    return this.http.post<Pago>(`${this.url}/culqi`, dto);
  }
}
