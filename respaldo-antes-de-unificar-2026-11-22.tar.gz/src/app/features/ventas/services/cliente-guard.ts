import { inject } from '@angular/core';
import { CanActivateFn, Router, RouterStateSnapshot } from '@angular/router';
import { SesionClienteService } from './sesion-cliente-service';

/** Si no hay sesión, abre la ventana de login sobre el catálogo y recuerda a dónde quería ir el cliente. */
export const clienteGuard: CanActivateFn = (_route, state: RouterStateSnapshot) => {
  const sesion = inject(SesionClienteService);
  if (sesion.autenticado()) return true;
  sesion.abrirLogin(state.url);
  return inject(Router).createUrlTree(['/tienda']);
};
