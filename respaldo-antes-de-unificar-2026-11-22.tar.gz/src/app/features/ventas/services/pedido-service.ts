import { inject, Service } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { Pedido, PedidoRequest } from '../models/pedido.model';

@Service()
export class PedidoService {
  private readonly http = inject(HttpClient);
  private readonly url = `${environment.apiUrl}/ventas/pedidos`;

  listar(): Observable<Pedido[]> {
    return this.http.get<Pedido[]>(this.url);
  }
  obtener(id: number): Observable<Pedido> {
    return this.http.get<Pedido>(`${this.url}/${id}`);
  }
  crear(dto: PedidoRequest): Observable<Pedido> {
    return this.http.post<Pedido>(this.url, dto);
  }
  cancelar(id: number): Observable<Pedido> {
    return this.http.post<Pedido>(`${this.url}/${id}/cancelar`, {});
  }
}
