import { Service } from '@angular/core';
import { environment } from '../../../../environments/environment';

/** Tipos mínimos del Checkout de Culqi (el script se carga dinámicamente). */
interface CulqiInstancia {
  token?: { id: string };
  error?: { user_message?: string; merchant_message?: string };
  culqi: () => void;
  open: () => void;
  close: () => void;
}
type CulqiConstructor = new (llave: string, config: unknown) => CulqiInstancia;

export type MetodoCulqi = 'yape' | 'tarjeta';

export type ResultadoCulqi = { token: string } | { error: string } | { cancelado: true };

/** Abre el Checkout de Culqi (tarjeta y Yape) y devuelve el token. El cobro real lo hace el backend. */
@Service()
export class CulqiService {
  private cargando?: Promise<void>;
  private descartarAnterior?: () => void;

  get configurada(): boolean {
    return /^pk_(test|live)_/.test(environment.culqiPublicKey) && !environment.culqiPublicKey.includes('REEMPLAZAR');
  }

  async pagar(monto: number, metodo: MetodoCulqi): Promise<ResultadoCulqi> {
    if (!this.configurada) {
      return { error: 'Falta configurar la llave pública de Culqi (pk_test_...) en src/environments/environment.ts.' };
    }
    try {
      await this.cargarScript();
    } catch (e) {
      return { error: (e as Error).message };
    }
    const Checkout = (window as unknown as { CulqiCheckout?: CulqiConstructor }).CulqiCheckout;
    if (!Checkout) return { error: 'Culqi no está disponible. Recarga la página.' };

    return new Promise<ResultadoCulqi>((resolver) => {
      let resuelto = false;
      const terminar = (r: ResultadoCulqi) => {
        if (!resuelto) {
          resuelto = true;
          resolver(r);
        }
      };
      const culqi = new Checkout(environment.culqiPublicKey, {
        settings: { title: environment.nombreComercio, currency: environment.moneda, amount: Math.round(monto * 100) },
        options: {
          lang: 'auto',
          installments: false,
          modal: true,
          paymentMethods: {
            tarjeta: metodo === 'tarjeta',
            yape: metodo === 'yape',
            billetera: false,
            bancaMovil: false,
            agente: false,
            cuotealo: false,
          },
          paymentMethodsSort: [metodo],
        },
      });
      culqi.culqi = () => {
        if (culqi.token) {
          const id = culqi.token.id;
          culqi.close();
          terminar({ token: id });
        } else if (culqi.error) {
          terminar({ error: culqi.error.user_message || culqi.error.merchant_message || 'Culqi rechazó el pago.' });
        }
      };
      // Culqi no avisa si cierran el modal: la pantalla ofrece "Reintentar" y se descarta la promesa anterior.
      this.descartarAnterior?.();
      this.descartarAnterior = () => terminar({ cancelado: true });
      culqi.open();
    });
  }

  private cargarScript(): Promise<void> {
    if ((window as unknown as { CulqiCheckout?: unknown }).CulqiCheckout) return Promise.resolve();
    this.cargando ??= new Promise<void>((ok, fallo) => {
      const script = document.createElement('script');
      script.src = environment.culqiScriptUrl;
      script.async = true;
      script.onload = () => ok();
      script.onerror = () => {
        this.cargando = undefined;
        fallo(new Error('No se pudo cargar Culqi. Revisa tu conexión a internet.'));
      };
      document.head.appendChild(script);
    });
    return this.cargando;
  }
}
