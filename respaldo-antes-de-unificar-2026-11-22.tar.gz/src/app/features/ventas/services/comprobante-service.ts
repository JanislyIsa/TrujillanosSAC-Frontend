import { inject, Service } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { Comprobante, ComprobanteRequest } from '../models/comprobante.model';

@Service()
export class ComprobanteService {
  private readonly http = inject(HttpClient);
  private readonly url = `${environment.apiUrl}/ventas/comprobantes`;

  emitir(dto: ComprobanteRequest): Observable<Comprobante> {
    return this.http.post<Comprobante>(this.url, dto);
  }
}
