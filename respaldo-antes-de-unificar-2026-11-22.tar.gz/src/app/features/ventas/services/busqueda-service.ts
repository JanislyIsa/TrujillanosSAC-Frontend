import { Service, signal } from '@angular/core';

/** Texto de la barra de búsqueda del encabezado; el catálogo filtra con él. */
@Service()
export class BusquedaService {
  readonly texto = signal('');
}
