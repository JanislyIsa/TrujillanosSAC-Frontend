import { CurrencyPipe, NgOptimizedImage } from '@angular/common';
import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ItemCarrito } from '../../models/carrito.model';
import { CarritoService } from '../../services/carrito-service';

@Component({
  selector: 'app-carrito',
  imports: [RouterLink, CurrencyPipe, NgOptimizedImage],
  templateUrl: './carrito.html',
  styleUrl: './carrito.css',
})
export class Carrito {
  protected readonly carrito = inject(CarritoService);

  protected cambiar(item: ItemCarrito, cantidad: number): void {
    this.carrito.fijar(item.producto, cantidad);
  }

  protected quitar(item: ItemCarrito): void {
    this.carrito.quitar(item.producto.idProducto);
  }
}
