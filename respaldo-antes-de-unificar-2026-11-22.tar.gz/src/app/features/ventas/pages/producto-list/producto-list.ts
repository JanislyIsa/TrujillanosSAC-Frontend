import { HttpErrorResponse } from '@angular/common/http';
import { CurrencyPipe, NgOptimizedImage } from '@angular/common';
import { Component, computed, inject, OnInit, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { mensajeError } from '../../../../core/utils/https-errors';
import { agruparProductos, GrupoProducto, primerDato, ProductoVenta, tipoPresentacion, variante } from '../../models/producto-venta.model';
import { BusquedaService } from '../../services/busqueda-service';
import { CarritoService } from '../../services/carrito-service';
import { ProductoVentaService } from '../../services/producto-venta-service';

@Component({
  selector: 'app-producto-list',
  imports: [RouterLink, CurrencyPipe, NgOptimizedImage],
  templateUrl: './producto-list.html',
  styleUrl: './producto-list.css',
})
export class ProductoList implements OnInit {
  private readonly productoService = inject(ProductoVentaService);
  private readonly busqueda = inject(BusquedaService);
  protected readonly carrito = inject(CarritoService);

  protected readonly productos = signal<ProductoVenta[]>([]);
  protected readonly cargando = signal(false);
  protected readonly error = signal<string | null>(null);
  protected readonly filtrados = computed(() => {
    const texto = this.busqueda.texto().trim().toLowerCase();
    return agruparProductos(this.productos()).filter(
      (g) =>
        !texto ||
        g.nombre.toLowerCase().includes(texto) ||
        g.variantes.some(
          (p) => (p.descripcion ?? '').toLowerCase().includes(texto) || (p.categoria ?? '').toLowerCase().includes(texto),
        ),
    );
  });

  ngOnInit(): void {
    this.cargar();
  }

  protected cargar(): void {
    this.cargando.set(true);
    this.error.set(null);
    this.productoService.listar().subscribe({
      next: (respuesta) => {
        this.productos.set(respuesta);
        this.cargando.set(false);
      },
      error: (err: HttpErrorResponse) => {
        this.error.set(mensajeError(err));
        this.cargando.set(false);
      },
    });
  }

  protected readonly foto = (g: GrupoProducto) => primerDato(g, 'imagenUrl');
  protected readonly tipoDe = tipoPresentacion;
  protected readonly conPaquete = (g: GrupoProducto) => variante(g, 'paquete');
  protected readonly conCaja = (g: GrupoProducto) => variante(g, 'caja');

  /** Lo que agrega el botón de la tarjeta: el paquete, o la única presentación que haya. */
  protected principal(g: GrupoProducto): ProductoVenta {
    return g.variantes[0];
  }

  protected agregar(g: GrupoProducto): void {
    const p = this.principal(g);
    this.carrito.agregar({ ...p, imagenUrl: p.imagenUrl ?? this.foto(g) });
  }

  protected sinStock(p: ProductoVenta): boolean {
    return p.stock <= 0 || this.carrito.cantidadDe(p.idProducto) >= p.stock;
  }
}
