import { HttpErrorResponse } from '@angular/common/http';
import { CurrencyPipe } from '@angular/common';
import { Component, computed, inject, input, OnInit, signal } from '@angular/core';
import { NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { mensajeError } from '../../../../core/utils/https-errors';
import { Pedido } from '../../models/pedido.model';
import { CarritoService } from '../../services/carrito-service';
import { CulqiService, MetodoCulqi } from '../../services/culqi-service';
import { PagoService } from '../../services/pago-service';
import { PedidoService } from '../../services/pedido-service';

type Paso = 'inicio' | 'creando' | 'esperando' | 'cobrando';

/**
 * Pantalla de pago.
 * - Sin :id → paga el carrito (crea el pedido y abre Culqi).
 * - Con :id → reintenta el pago de un pedido pendiente.
 */
@Component({
  selector: 'app-pedido-form',
  imports: [ReactiveFormsModule, RouterLink, CurrencyPipe],
  templateUrl: './pedido-form.html',
  styleUrl: './pedido-form.css',
})
export class PedidoForm implements OnInit {
  private readonly fb = inject(NonNullableFormBuilder);
  private readonly router = inject(Router);
  private readonly pedidoService = inject(PedidoService);
  private readonly pagoService = inject(PagoService);
  protected readonly carrito = inject(CarritoService);
  protected readonly culqi = inject(CulqiService);

  readonly id = input<string>();
  protected readonly vigenciaMinutos = 30;
  protected readonly pedido = signal<Pedido | null>(null);
  protected readonly cargando = signal(false);
  protected readonly paso = signal<Paso>('inicio');
  protected readonly errorMsg = signal<string | null>(null);
  protected readonly metodo = signal<MetodoCulqi>('yape');
  protected readonly form = this.fb.group({
    email: ['', [Validators.required, Validators.email, Validators.maxLength(150)]],
  });

  protected readonly total = computed(() => this.pedido()?.total ?? this.carrito.total());
  protected readonly hayAlgoQuePagar = computed(() => this.pedido() !== null || this.carrito.items().length > 0);

  ngOnInit(): void {
    const rawId = this.id();
    if (!rawId) return;
    const id = Number(rawId);
    if (!Number.isInteger(id) || id <= 0) {
      this.errorMsg.set('No se encontró el pedido. El identificador no es válido.');
      return;
    }
    this.cargando.set(true);
    this.pedidoService.obtener(id).subscribe({
      next: (p) => {
        this.pedido.set(p);
        this.cargando.set(false);
      },
      error: (e: HttpErrorResponse) => {
        this.errorMsg.set(mensajeError(e));
        this.cargando.set(false);
      },
    });
  }

  protected async pagar(): Promise<void> {
    this.errorMsg.set(null);
    this.form.markAllAsTouched();
    if (this.form.invalid || !this.culqi.configurada || this.paso() !== 'inicio') return;

    let pedido = this.pedido();
    if (!pedido) {
      this.paso.set('creando');
      try {
        pedido = await firstValueFrom(
          this.pedidoService.crear({
            detalles: this.carrito.items().map((i) => ({ productoId: i.producto.idProducto, cantidad: i.cantidad })),
          }),
        );
      } catch (e) {
        this.errorMsg.set(mensajeError(e as HttpErrorResponse));
        this.paso.set('inicio');
        return;
      }
      this.pedido.set(pedido);
      this.carrito.vaciar();
    }
    await this.cobrar(pedido);
  }

  protected async cobrar(pedido: Pedido): Promise<void> {
    this.errorMsg.set(null);
    this.paso.set('esperando');
    const resultado = await this.culqi.pagar(pedido.total, this.metodo());

    if ('token' in resultado) {
      this.paso.set('cobrando');
      try {
        const pago = await firstValueFrom(
          this.pagoService.pagarConCulqi({
            pedidoId: pedido.idPedido,
            token: resultado.token,
            email: this.form.getRawValue().email.trim(),
          }),
        );
        if (pago.estado === 'APROBADO') {
          void this.router.navigate(['/tienda/pago-completado', pedido.idPedido]);
          return;
        }
        this.errorMsg.set(pago.mensaje || 'El pago no fue aprobado. Puedes intentarlo de nuevo.');
      } catch (e) {
        this.errorMsg.set(mensajeError(e as HttpErrorResponse));
      }
      this.paso.set('inicio');
    } else if ('error' in resultado) {
      this.errorMsg.set(resultado.error);
      this.paso.set('inicio');
    }
    // cancelado: se mantiene la pantalla de espera con el botón "Reintentar pago"
  }
}
