import { HttpErrorResponse } from '@angular/common/http';
import { Component, effect, ElementRef, inject, signal, viewChild } from '@angular/core';
import { NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { mensajeError } from '../../../../core/utils/https-errors';
import { SesionClienteService } from '../../services/sesion-cliente-service';

/** Ventana de inicio de sesión (modal) que aparece sobre el catálogo. */
@Component({
  selector: 'app-login-cliente',
  imports: [ReactiveFormsModule],
  templateUrl: './login-cliente.html',
  styleUrl: './login-cliente.css',
})
export class LoginCliente {
  private readonly fb = inject(NonNullableFormBuilder);
  private readonly sesion = inject(SesionClienteService);
  private readonly dialogo = viewChild.required<ElementRef<HTMLDialogElement>>('dialogo');

  protected readonly ingresando = signal(false);
  protected readonly verClave = signal(false);
  protected readonly errorMsg = signal<string | null>(null);
  protected readonly form = this.fb.group({
    username: ['', [Validators.required, Validators.maxLength(20)]],
    password: ['', [Validators.required]],
  });

  constructor() {
    effect(() => {
      const dialogo = this.dialogo().nativeElement;
      if (this.sesion.loginAbierto()) {
        if (!dialogo.open) dialogo.showModal();
      } else if (dialogo.open) {
        dialogo.close();
      }
    });
  }

  protected cerrar(): void {
    this.errorMsg.set(null);
    this.form.reset();
    this.sesion.cerrarLogin();
  }

  protected ingresar(): void {
    this.errorMsg.set(null);
    this.form.markAllAsTouched();
    if (this.form.invalid || this.ingresando()) return;
    const { username, password } = this.form.getRawValue();
    this.ingresando.set(true);
    this.sesion.iniciarSesion({ username: username.trim(), password }).subscribe({
      next: () => {
        this.ingresando.set(false);
        this.form.reset();
      },
      error: (e: unknown) => {
        this.errorMsg.set(e instanceof HttpErrorResponse ? mensajeError(e) : (e as Error).message);
        this.ingresando.set(false);
      },
    });
  }
}
