import { HttpErrorResponse } from '@angular/common/http';
import { CurrencyPipe, DatePipe } from '@angular/common';
import { Component, inject, OnInit, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { mensajeError } from '../../../../core/utils/https-errors';
import { etiquetaEstado, Pedido, resumenProductos } from '../../models/pedido.model';
import { PedidoService } from '../../services/pedido-service';

@Component({
  selector: 'app-pedido-list',
  imports: [RouterLink, CurrencyPipe, DatePipe],
  templateUrl: './pedido-list.html',
  styleUrl: './pedido-list.css',
})
export class PedidoList implements OnInit {
  private readonly pedidoService = inject(PedidoService);
  protected readonly pedidos = signal<Pedido[]>([]);
  protected readonly cargando = signal(false);
  protected readonly error = signal<string | null>(null);
  protected readonly etiqueta = etiquetaEstado;
  protected readonly resumen = resumenProductos;

  ngOnInit(): void {
    this.cargando.set(true);
    this.pedidoService.listar().subscribe({
      next: (respuesta) => {
        this.pedidos.set([...respuesta].sort((a, b) => b.idPedido - a.idPedido));
        this.cargando.set(false);
      },
      error: (err: HttpErrorResponse) => {
        this.error.set(mensajeError(err));
        this.cargando.set(false);
      },
    });
  }
}
