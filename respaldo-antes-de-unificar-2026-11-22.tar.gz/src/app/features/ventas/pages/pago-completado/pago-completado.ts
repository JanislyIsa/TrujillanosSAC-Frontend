import { Component, input } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-pago-completado',
  imports: [RouterLink],
  templateUrl: './pago-completado.html',
  styleUrl: './pago-completado.css',
})
export class PagoCompletado {
  readonly id = input.required<string>();
}
