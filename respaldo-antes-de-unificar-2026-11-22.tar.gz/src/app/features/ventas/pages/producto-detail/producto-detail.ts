import { HttpErrorResponse } from '@angular/common/http';
import { CurrencyPipe, NgOptimizedImage } from '@angular/common';
import { Component, computed, inject, input, OnInit, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { mensajeError } from '../../../../core/utils/https-errors';
import { agruparProductos, GrupoProducto, primerDato, ProductoVenta, TipoPresentacion, tipoPresentacion, variante } from '../../models/producto-venta.model';
import { CarritoService } from '../../services/carrito-service';
import { ProductoVentaService } from '../../services/producto-venta-service';

@Component({
  selector: 'app-producto-detail',
  imports: [RouterLink, CurrencyPipe, NgOptimizedImage],
  templateUrl: './producto-detail.html',
  styleUrl: './producto-detail.css',
})
export class ProductoDetail implements OnInit {
  private readonly productoService = inject(ProductoVentaService);
  private readonly router = inject(Router);
  protected readonly carrito = inject(CarritoService);

  readonly id = input.required<string>();
  /** Todas las presentaciones del producto (Paquete y/o Caja). */
  protected readonly grupo = signal<GrupoProducto | null>(null);
  protected readonly seleccion = signal<TipoPresentacion>('paquete');
  protected readonly cargando = signal(false);
  protected readonly error = signal<string | null>(null);

  /** Variante elegida: tiene su propio precio y stock. */
  protected readonly producto = computed<ProductoVenta | null>(() => {
    const g = this.grupo();
    return g ? (variante(g, this.seleccion()) ?? g.variantes[0]) : null;
  });
  protected readonly descripcion = computed(() => {
    const g = this.grupo();
    return g ? primerDato(g, 'descripcion') : null;
  });
  protected readonly imagen = computed(() => {
    const g = this.grupo();
    return g ? primerDato(g, 'imagenUrl') : null;
  });
  protected readonly precioCaja = computed(() => this.precioDe('caja'));
  protected readonly precioPaquete = computed(() => this.precioDe('paquete'));

  ngOnInit(): void {
    const id = Number(this.id());
    if (!Number.isInteger(id) || id <= 0) {
      this.error.set('No se encontró el producto. El identificador no es válido.');
      return;
    }
    this.cargando.set(true);
    // El catálogo trae una fila por presentación; se buscan las del mismo producto.
    this.productoService.listar().subscribe({
      next: (lista) => {
        const elegido = lista.find((p) => p.idProducto === id);
        if (!elegido) {
          this.error.set('No se encontró el producto o ya no está disponible.');
        } else {
          const g = agruparProductos(lista).find((x) => x.variantes.some((v) => v.idProducto === id)) ?? null;
          this.grupo.set(g);
          this.seleccion.set(tipoPresentacion(elegido));
        }
        this.cargando.set(false);
      },
      error: (e: HttpErrorResponse) => {
        this.error.set(mensajeError(e));
        this.cargando.set(false);
      },
    });
  }

  protected tiene(tipo: TipoPresentacion): boolean {
    const g = this.grupo();
    return !!g && !!variante(g, tipo);
  }

  private precioDe(tipo: TipoPresentacion): number | null {
    const g = this.grupo();
    return g ? (variante(g, tipo)?.precio ?? null) : null;
  }

  protected agregar(p: ProductoVenta): void {
    // La fila CAJA puede no tener foto propia: se usa la del producto.
    this.carrito.agregar({ ...p, imagenUrl: p.imagenUrl ?? this.imagen() });
    void this.router.navigate(['/tienda/carrito']);
  }

  protected sinStock(p: ProductoVenta): boolean {
    return p.stock <= 0 || this.carrito.cantidadDe(p.idProducto) >= p.stock;
  }
}
