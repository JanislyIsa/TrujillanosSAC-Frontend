import { HttpErrorResponse } from '@angular/common/http';
import { CurrencyPipe, DatePipe } from '@angular/common';
import { Component, inject, input, OnInit, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { mensajeError } from '../../../../core/utils/https-errors';
import { Comprobante, TipoComprobante } from '../../models/comprobante.model';
import { Pago } from '../../models/pago.model';
import { claseEstado, Pedido } from '../../models/pedido.model';
import { ComprobanteService } from '../../services/comprobante-service';
import { PagoService } from '../../services/pago-service';
import { PedidoService } from '../../services/pedido-service';


@Component({
  selector: 'app-pedido-detail',
  imports: [RouterLink, CurrencyPipe, DatePipe],
  templateUrl: './pedido-detail.html',
  styleUrl: './pedido-detail.css',
})
export class PedidoDetail implements OnInit {
  private readonly pedidoService = inject(PedidoService);
  private readonly pagoService = inject(PagoService);
  private readonly comprobanteService = inject(ComprobanteService);

  readonly id = input.required<string>();

  protected readonly pedido = signal<Pedido | null>(null);
  protected readonly pagos = signal<Pago[]>([]);
  protected readonly comprobante = signal<Comprobante | null>(null);
  protected readonly cargando = signal(false);
  protected readonly ocupado = signal(false);
  protected readonly errorMsg = signal<string | null>(null);
  protected readonly aviso = signal<string | null>(null);
  protected readonly clase = claseEstado;

  ngOnInit(): void {
    const id = Number(this.id());
    if (!Number.isInteger(id) || id <= 0) {
      this.errorMsg.set('No se encontró el pedido. El identificador no es válido.');
      return;
    }
    this.cargando.set(true);
    this.pedidoService.obtener(id).subscribe({
      next: (p) => {
        this.pedido.set(p);
        this.cargando.set(false);
      },
      error: (e: HttpErrorResponse) => {
        this.errorMsg.set(mensajeError(e));
        this.cargando.set(false);
      },
    });
    this.pagoService.listarPorPedido(id).subscribe({
      next: (lista) => this.pagos.set(lista),
      error: () => this.pagos.set([]),
    });
  }

  protected puedeFacturar(p: Pedido): boolean {
    return ['PAGADO', 'LISTO_PARA_RECOJO', 'ENTREGADO'].includes(p.estado.codigo);
  }

  protected cancelar(p: Pedido): void {
    if (!confirm(`¿Cancelar el pedido #${p.idPedido}?`)) return;
    this.ocupado.set(true);
    this.errorMsg.set(null);
    this.pedidoService.cancelar(p.idPedido).subscribe({
      next: (actualizado) => {
        this.pedido.set(actualizado);
        this.aviso.set('Pedido cancelado.');
        this.ocupado.set(false);
      },
      error: (e: HttpErrorResponse) => {
        this.errorMsg.set(mensajeError(e));
        this.ocupado.set(false);
      },
    });
  }

  protected emitir(p: Pedido, tipo: TipoComprobante): void {
    this.ocupado.set(true);
    this.errorMsg.set(null);
    this.comprobanteService.emitir({ pedidoId: p.idPedido, tipo }).subscribe({
      next: (c) => {
        this.comprobante.set(c);
        this.ocupado.set(false);
      },
      error: (e: HttpErrorResponse) => {
        this.errorMsg.set(mensajeError(e));
        this.ocupado.set(false);
      },
    });
  }
}
