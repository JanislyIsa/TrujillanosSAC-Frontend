import { NgOptimizedImage } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { NavigationEnd, Router, RouterLink, RouterOutlet } from '@angular/router';
import { filter } from 'rxjs';
import { BusquedaService } from '../../services/busqueda-service';
import { CarritoService } from '../../services/carrito-service';
import { SesionClienteService } from '../../services/sesion-cliente-service';
import { LoginCliente } from '../login-cliente/login-cliente';

@Component({
  selector: 'app-tienda-layout',
  imports: [RouterOutlet, RouterLink, NgOptimizedImage, LoginCliente],
  templateUrl: './tienda-layout.html',
  styleUrl: './tienda-layout.css',
  host: { '(document:keydown.escape)': 'menuAbierto.set(false)' },
})
export class TiendaLayout {
  private readonly router = inject(Router);
  protected readonly busqueda = inject(BusquedaService);
  protected readonly sesion = inject(SesionClienteService);
  protected readonly carrito = inject(CarritoService);
  protected readonly menuAbierto = signal(false);

  constructor() {
    this.router.events.pipe(filter((e) => e instanceof NavigationEnd)).subscribe(() => this.menuAbierto.set(false));
  }

  protected buscar(texto: string): void {
    this.busqueda.texto.set(texto);
    if (this.router.url.split('?')[0] !== '/tienda') void this.router.navigate(['/tienda']);
  }

  protected cuenta(): void {
    if (this.sesion.autenticado()) this.menuAbierto.update((v) => !v);
    else this.sesion.abrirLogin();
  }

  protected salir(): void {
    this.menuAbierto.set(false);
    this.sesion.cerrarSesion();
  }
}
