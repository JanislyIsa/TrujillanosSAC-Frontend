import { Routes } from '@angular/router';
import { clienteGuard } from './services/cliente-guard';
import { Carrito } from './pages/carrito/carrito';
import { PagoCompletado } from './pages/pago-completado/pago-completado';
import { PedidoDetail } from './pages/pedido-detail/pedido-detail';
import { PedidoForm } from './pages/pedido-form/pedido-form';
import { PedidoList } from './pages/pedido-list/pedido-list';
import { ProductoDetail } from './pages/producto-detail/producto-detail';
import { ProductoList } from './pages/producto-list/producto-list';
import { TiendaLayout } from './pages/tienda-layout/tienda-layout';

export const VENTAS_ROUTES: Routes = [
  {
    path: '',
    component: TiendaLayout,
    children: [
      { path: '', component: ProductoList, title: 'Catálogo' },
      { path: 'login', redirectTo: '', pathMatch: 'full' },
      { path: 'producto/:id', component: ProductoDetail, title: 'Producto' },
      { path: 'carrito', component: Carrito, title: 'Carrito de compras' },
      { path: 'pagar', component: PedidoForm, canActivate: [clienteGuard], title: 'Pagar' },
      { path: 'pagar/:id', component: PedidoForm, canActivate: [clienteGuard], title: 'Pagar pedido' },
      { path: 'pago-completado/:id', component: PagoCompletado, canActivate: [clienteGuard], title: 'Pago completado' },
      { path: 'pedidos', component: PedidoList, canActivate: [clienteGuard], title: 'Mis pedidos' },
      { path: 'pedidos/:id', component: PedidoDetail, canActivate: [clienteGuard], title: 'Detalle del pedido' },
    ],
  },
];
